package com.example.inmobiliaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InmobiliariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
