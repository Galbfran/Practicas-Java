package com.example.arquitecturaCapas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquitecturaCapasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquitecturaCapasApplication.class, args);
	}

}
