package com.example.arquitecturaCapas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArquitecturaCapasApplicationTests {

	@Test
	void contextLoads() {
	}

}
